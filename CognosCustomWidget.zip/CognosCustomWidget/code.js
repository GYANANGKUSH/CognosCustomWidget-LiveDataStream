define([
	'jquery',
	'dashboard/widgets/CustomWidget',
	'http://d3js.org/d3.v4.min.js'
], function( $, Base, d3) {

	var historicalData = [
        {"id": 1, "temperature":90, "pressure":35, "vibration":15},
        {"id": 2, "temperature":55, "pressure":40, "vibration":20},
        {"id": 3, "temperature":120, "pressure":50, "vibration":45},
        {"id": 4, "temperature":135, "pressure":100, "vibration":30},
        {"id": 5, "temperature":100, "pressure":80, "vibration":70},
        {"id": 6, "temperature":149, "pressure":70, "vibration":65},
        {"id": 7, "temperature":170, "pressure":35, "vibration":15},
        {"id": 8, "temperature":180, "pressure":40, "vibration":20},
        {"id": 9, "temperature":190, "pressure":50, "vibration":45},
        {"id": 10, "temperature":95, "pressure":100, "vibration":30},
        {"id": 11, "temperature":55, "pressure":80, "vibration":15},
        {"id": 12, "temperature":120, "pressure":70, "vibration":20},
        {"id": 13, "temperature":135, "pressure":95, "vibration":45},
        {"id": 14, "temperature":100, "pressure":55, "vibration":30},
        {"id": 15, "temperature":149, "pressure":120, "vibration":30},
        {"id": 16, "temperature":170, "pressure":135, "vibration":70},
        {"id": 17, "temperature":180, "pressure":33, "vibration":65},
        {"id": 18, "temperature":190, "pressure":90, "vibration":15},
        {"id": 19, "temperature":95, "pressure":80, "vibration":20},
        {"id": 20, "temperature":55, "pressure":70, "vibration":45},
        {"id": 21, "temperature":120, "pressure":35, "vibration":30},
        {"id": 22, "temperature":135, "pressure":40, "vibration":15},
        {"id": 23, "temperature":33, "pressure":50, "vibration":20},
        {"id": 24, "temperature":90, "pressure":35, "vibration":10},
				{"id": 25, "temperature":90, "pressure":35, "vibration":15},
				{"id": 26, "temperature":55, "pressure":40, "vibration":20},
				{"id": 27, "temperature":120, "pressure":50, "vibration":45},
				{"id": 28, "temperature":135, "pressure":100, "vibration":30},
				{"id": 29, "temperature":100, "pressure":80, "vibration":70},
				{"id": 30, "temperature":149, "pressure":70, "vibration":65},
				{"id": 31, "temperature":170, "pressure":35, "vibration":15},
				{"id": 32, "temperature":180, "pressure":40, "vibration":20},
				{"id": 33, "temperature":190, "pressure":50, "vibration":45},
				{"id": 34, "temperature":95, "pressure":100, "vibration":30},
				{"id": 35, "temperature":55, "pressure":80, "vibration":15},
				{"id": 36, "temperature":120, "pressure":70, "vibration":20},
				{"id": 37, "temperature":135, "pressure":95, "vibration":45},
				{"id": 38, "temperature":100, "pressure":55, "vibration":30},
				{"id": 39, "temperature":149, "pressure":120, "vibration":30},
				{"id": 40, "temperature":170, "pressure":135, "vibration":70},
				{"id": 41, "temperature":180, "pressure":33, "vibration":65},
				{"id": 42, "temperature":190, "pressure":90, "vibration":15},
				{"id": 43, "temperature":95, "pressure":80, "vibration":20},
				{"id": 44, "temperature":55, "pressure":70, "vibration":45},
				{"id": 45, "temperature":120, "pressure":35, "vibration":30},
				{"id": 46, "temperature":135, "pressure":40, "vibration":15},
				{"id": 47, "temperature":33, "pressure":50, "vibration":20},
				{"id": 48, "temperature":90, "pressure":35, "vibration":10}
    ];

	var Widget = Base.extend({
		onInit: function(params) {
			this.name = params.name;
		},
		onRender: function() {
			var root = this.getContentRootNode();
			$(root).append('<div id="titleContainer" class="titleContainer"> Visualization of ' + this.name + ' data for the last 24 Hours</div><br/>');
			$(root).append('<div id="tableContainer" class="tableContainer"></div>');
			$(root).append('<div id="noteContainer" class="noteContainer">*Note: Click on any attribute (Pressure/Temperature/Vibration) column to view live streaming. </div><br/>');

			var chartContainer = '<div id="chartContainer" class="chartContainer">' +
									'<div id="chartHeader" class="chartHeader">Live Streaming</div>' +
									'<div id="livelinechart" class="livelinechart"></div>' +
								'</div>';

			$(root).append(chartContainer);
			uploadTable();

			$('#myTable').delegate('tr td:nth-child(2)', 'click', function() {
				alert("Live streaming of Pressure data...");
				$('.chartContainer'). show();
				drawLineChart("pressure");
			});
			$('#myTable').delegate('tr td:nth-child(3)', 'click', function() {
				alert("Live streaming of Temperature data...");
				$('.chartContainer'). show();
				drawLineChart("temperature");
			});
			$('#myTable').delegate('tr td:nth-child(4)', 'click', function() {
				alert("Live streaming of Vibration data...");
				$('.chartContainer'). show();
				drawLineChart("vibration");
			});
		}
	});

	// function to upload static data in tabular form
	function uploadTable(){
		var dt = new Date();
        var today = dt.getDate() + "-" + (dt.getMonth() +1) + "-" + dt.getFullYear();
        var yday = (dt.getDate()-1) + "-" + (dt.getMonth() +1) + "-" + dt.getFullYear();
        var reading_time, reading_date, counter=48, time;
		var content = "<table id='myTable'>";
		var i;
		content += "<thead> <th>Sl. no.</th> <th>Temperature</th> <th>Pressure</th> <th>Vibration</th> <th>Time</th> <th>Date</th></thead>";
		content += "<tbody>";

		for (i=0; i<48; i++) {
			time = (dt.getHours()-i) + ":00"
            if ((dt.getHours()-i) <= 0) {
                reading_time = ((counter != 48) ? (counter + ":00") : "00:00");
                reading_date = yday;
                counter--;
            } else {
                reading_time = time;
                reading_date = today;
            }

            content += "<tr>";
            content += "<td>" + historicalData[i].id + "</td>";
            content += "<td>" + historicalData[i].temperature + "</td>";
			content += "<td>" + historicalData[i].pressure + "</td>";
            content += "<td>" + historicalData[i].vibration + "</td>";
			content += "<td>" + reading_time + "</td>";
			content += "<td>" + reading_date + "</td>";
			content += "</tr>";
		}
		content += "</table>";
		$('#tableContainer').append( content );
	}

	// function to add seconds in current time
	var addSeconds = function AddSecondsToDate(date, seconds) {
    	return new Date(date.getTime() + seconds*1000);
	}

	// function to draw line chart for live streaming
	function drawLineChart(param) {
		var data = [];
		var margin = {top: 10, right: 50, bottom: 50, left: 50};
		var width = 1000;
		var height = 250;
		var globalX = 0;
		var duration = 700;
		var max = 100;
		var step = 10;
		var date = new Date();
		var formatDate = d3.timeFormat("%H:%M:%S");

		var x = d3.scaleTime().range([0, width]);

		if (param == "temperature"){
			//var x = d3.scaleLinear().domain([0, 60]).range([0, width]);
			var y = d3.scaleLinear().domain([0, 220]).range([height, 0]);

			var minX=0, maxX=1100, minY=40, maxY=40;
			var minX1=0, maxX1=1100, minY1=180, maxY1=180;

			var allowed_val = 180;
			var minVal = 20;
			var lineColor = "red";
			var label = "Temperature (°C)";
		} else if (param == "pressure"){
			//var x = d3.scaleLinear().domain([0, 60]).range([0, width]);
			var y = d3.scaleLinear().domain([0, 180]).range([height, 0]);

			var minX=0, maxX=1100, minY=35, maxY=35;
			var minX1=0, maxX1=1100, minY1=130, maxY1=130;

			var allowed_val = 130;
			var minVal = 20;
			var lineColor = "#1E90FF";
			var label = "Pressure (psi)";
		} else {
			//var x = d3.scaleLinear().domain([0, 60]).range([0, width]);
			var y = d3.scaleLinear().domain([0, 100]).range([height, 0]);

			var minX=0, maxX=1100, minY=0, maxY=0;
			var minX1=0, maxX1=1100, minY1=50, maxY1=50;

			var allowed_val = 50;
			var minVal = 0;
			var lineColor = "#f1c40f";
			var label = "Vibration (Hz)";
		}

		//to clear the previous chart in container if any
		d3.select("#livelinechart").selectAll("svg").remove();

		var chart = d3.select("#livelinechart").append("svg")
				.attr('width', width + margin.left + margin.right)
				.attr('height', height + margin.bottom)
				.append("g")
				.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
				;

		// -----------------------------------
		var line = d3.line()
							.x(function(d){ return x(d.x); })
							.y(function(d){ return y(d.y); });
		var smoothLine = d3.line().curve(d3.curveCardinal)
							.x(function(d){ return x(d.x); })
							.y(function(d){ return y(d.y); });
		var lineArea = d3.area()
							.x(function(d){ return x(d.x); })
							.y0(y(0))
							.y1(function(d){ return y(d.y); })
							.curve(d3.curveCardinal);
		// -----------------------------------
		// Draw the axis
		var xAxis = d3.axisBottom(x).scale(x)
					.tickFormat(function(d,i){
						date = addSeconds(date, 1);
						return(formatDate(date));
					});
		var axisX = chart.append('g').attr('class', 'x axis')
					.attr('transform', 'translate(0,'+ height + ')')
					.call(xAxis);

		var yAxis = d3.axisLeft().scale(y);
		var axisY = chart.append('g').attr('class', 'y axis')
					.call(yAxis);

		// add labels - https://bl.ocks.org/d3noob/23e42c8f67210ac6c678db2cd07a747e
		// text label for the x axis
		chart.append("text")
		.attr("transform",
				"translate(" + (width/2) + " ," + (height+ 30) + ")")
		.style("text-anchor", "middle")
		.text("Time");

		// text label for the y axis
		chart.append("text")
		.attr("transform", "rotate(-90)")
		.attr("y", 0 - margin.left)
		.attr("x",0 - (height / 2))
		.attr("dy", "1em")
		.style("text-anchor", "middle")
		.text(label);

		// to resolve overflow issue
		//https://stackoverflow.com/questions/35784773/d3-js-line-graph-area-path-goes-over-x-and-y-axis-on-zoom
		clip = chart.append("svg:clipPath")
                .attr("id", "clip")
                .append("svg:rect")
                .attr("x", 0)
                .attr("y", 0)
                .attr("width", width)
                .attr("height", height);

    	chartBody = chart.append("g")
                .attr("clip-path", "url(#clip)");

		//Append the lines for threshold values
		//https://stackoverflow.com/questions/27951560/adding-a-horizontal-line-to-d3-graph-displays-at-the-wrong-value
		chartBody.append("svg:line")
            .attr("x1", minX)
            .attr("x2", maxX)
            .attr("y1", y(minY))
            .attr("y2", y(maxY))
			.style("stroke", "green")
			.style("stroke-width", "1px");

		chartBody.append("svg:line")
            .attr("x1", minX1)
            .attr("x2", maxX1)
            .attr("y1", y(minY1))
            .attr("y2", y(maxY1))
			.style("stroke", "green")
			.style("stroke-width", "1px");

    	// Append the holder for line chart and fill area
    	var path = chartBody.append('path');
    	var areaPath = chartBody.append('path');

		// Main loop
		function tick() {
			// Generate new data
			var point = {
				x: globalX,
				y: (((Math.random() * allowed_val) + minVal) >> 0)
			};
			data.push(point);
			globalX += step;
			// Draw new line
			path.datum(data)
				.attr('class', 'smoothline')
				.style("stroke", lineColor)
				.attr('d', smoothLine);
			// Draw new fill area
			//areaPath.datum(data)
				//.attr('class', 'area')
				//.attr('d', lineArea);

			// Shift the chart left
			x.domain([globalX - (max - step), globalX]);

			axisX.transition()
				.duration(duration)
				.ease(d3.easeLinear,2)
				.call(xAxis);
			path.attr('transform', null)
				.transition()
				.duration(duration)
				.ease(d3.easeLinear,2)
				.attr('transform', 'translate(' + x(globalX - max) + ')')
			areaPath.attr('transform', null)
				.transition()
				.duration(duration)
				.ease(d3.easeLinear,2)
				.attr('transform', 'translate(' + x(globalX - max) + ')')
				.on('end', tick)
			// Remote old data (max 50 points)
			if (data.length > 50) data.shift();
		}
    	tick();
	}

	return Widget;
});
